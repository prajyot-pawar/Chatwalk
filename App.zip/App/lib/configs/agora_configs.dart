const String APP_ID = "3d78afaa60f54388a81f68c0262a46bd";
const String TokenUrl =
    "0063d78afaa60f54388a81f68c0262a46bdIACjZ5vUVTCtEHHB1pmb0MpLZdbNvRln15nYAM6ekSYvdgpFMOAAAAAAEABr21wCKryPYQEAAQAdvI9h";
const String channelName = "chatwalk";
